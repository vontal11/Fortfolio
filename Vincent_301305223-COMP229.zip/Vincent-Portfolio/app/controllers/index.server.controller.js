exports.render = (req,res)=>{
    res.render('index',{
        title: 'Hello world'
    })
};

